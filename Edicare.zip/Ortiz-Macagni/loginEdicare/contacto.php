<?php
  //separo header de lo que contenga el medio de la pantalla
  require "header.php";
?>
<br>
<br>
   <link rel="stylesheet" href="style.css">
<p class="login-titulo">Contacta con los desarolladores</p>
<br>
<br>
<br>

<p class="login-subtituloAU"> Puedes contactar con nosotros directamente desde nuestras redes sociales detalladas</p>
<br>
<img src="img/facebook.png" class="logos">
<p class="login-subtituloAU"> Facebook.com/Edicare</p>
<br>
<img src="img/tw.png" class="logos">
<p class="login-subtituloAU"> Twitter.com/EdicareARG</p>
<br>
<img src="img/insta.png" class="logos">
<p class="login-subtituloAU"> Instagram.com/EdicareArg</p>
<br>
<img src="img/email.png" class="logos">
<p class="login-subtituloAU"> contacto@edicare.com.ar</p>